package demo2;

public class Sleep_wait {
private static Object LOCK=new Object();
public static void main(String a[]) throws InterruptedException
{
	Thread.sleep(1000);
	System.out.println("Thread "+Thread.currentThread().getName()+" is woking");
	synchronized(LOCK)
	{
		LOCK.wait(1000);
		System.out.println("Object "+LOCK+"Invoked after the wait of 1 seconds");
	}
}
}
