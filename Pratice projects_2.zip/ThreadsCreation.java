package demo2;

class Threaddemo extends Thread
{
	public void run()
	{
		System.out.println("Thread is running");
	}
}
public class ThreadsCreation {
public static void main(String args[]) {
	Threaddemo t1=new Threaddemo();
	t1.start();
}
}
