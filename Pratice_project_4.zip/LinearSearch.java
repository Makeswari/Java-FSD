package demo;
import java.util.Scanner;
class Ls
{
	public int search(int a[],int n,int k)
	{
		
		for(int i=0;i<n;i++)
		{
			if(a[i]==k)
			{
				
				return i;	
			}
			
		}
		return -1;
	}
}
public class LinearSearch {
	public static void main (String[]a)
	{
		Scanner c=new Scanner(System.in);
		int n,k;
		System.out.println("Enter the number of value");
		n=c.nextInt();
		k=c.nextInt();
		int arr[]=new int[n];
		for(int i=0;i<n;i++)
		{
		arr[i]=c.nextInt();	
		}
		Ls o=new Ls();
		int res=o.search(arr,n,k);
		if(res==-1) {
			System.out.println("Element Not found");
		}
		else
			System.out.println("Element "+k+" found at "+res);

		
	}

	
}
