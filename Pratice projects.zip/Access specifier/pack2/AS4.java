package pack2;
import pack1.*;
public class AS4 {
public static void main(String[] args) {
		
		Public obj = new Public(); 
        obj.display();  
		
	}

}
