package pack2;
import pack1.*;
public class AS3 extends Protected {
	

		public static void main(String[] args) {
			AS3 obj = new AS3 ();   
		       obj.display();  
		}

	

}
